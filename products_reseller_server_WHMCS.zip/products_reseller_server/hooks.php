<?php

if (!defined("WHMCS")) {
    die("This file cannot be accessed directly");
}

use WHMCS\Database\Capsule;
use WHMCS\View\Menu\Item as MenuItem;

require_once __DIR__ . '/pr_server_classes.php';

add_hook('AdminAreaFooterOutput', 1, function($vars) {
    
    
    if (strpos($_SERVER['REQUEST_URI'], 'clientsservices.php') !== false && !empty($_GET['id'])) {
        $serviceId = (int)$_GET['id'];

        $service = Capsule::table('tblhosting')
            ->join('tblservers', 'tblhosting.server', '=', 'tblservers.id')
            ->where('tblhosting.id', $serviceId)
            ->where('tblservers.type', 'products_reseller_server')
            ->select('tblhosting.id', 'tblhosting.server')
            ->first();

        if ($service) {
            $main_class = new ProductsReseller_Main();
            try {
                $res = $main_class->get_server_name([
                    'serviceid' => $service->id,
                    'server_id' => $service->server,
                    'action'    => 'GetServerName'
                ]);

                // If it's NOT 'cpanel', hide the login button
                if (empty($res['server_name']) || strtolower($res['server_name']) !== 'cpanel') {
                    return <<<HTML
<script>
$(document).ready(function() {
    $('button[onclick*="runModuleCommand"][onclick*="singlesignon"]').closest('.btn-group').find('button:first').hide();
});
</script>
HTML;
                }
            } catch (Exception $e) {
                return <<<HTML
<script>
$(document).ready(function() {
    $('button[onclick*="runModuleCommand"][onclick*="singlesignon"]').closest('.btn-group').find('button:first').hide();
});
</script>
HTML;
            }
        }
    }

    if (strpos($_SERVER['REQUEST_URI'], 'configservers.php') !== false && isset($_GET['action'], $_GET['id']) && $_GET['action'] === 'manage') {
        
        $serverId = (int) $_GET['id'];

        $server = Capsule::table('tblservers')
            ->where('id', $serverId)
            ->where('type', 'products_reseller_server')
            ->where('active', 1)
            ->first();

        if ($server) {
            return <<<HTML
<script>
$(document).ready(function() {

    
    $("td.fieldlabel:contains('Username')").each(function() {
        if ($(this).text().trim() === "Username") {
            $(this).text("API Endpoint");
        }
    });

    $("td.fieldlabel:contains('Password')").each(function() {
        if ($(this).text().trim() === "Password") {
            $(this).text("API Key");
        }
    });
});
</script>
HTML;
        }
    }
});
